# react-seed
React seed application with Webpack 4, Babel, ESLint Rules, JSConfig &amp; Jest-Enzyme Test Framework


Steps to run in local:-
1. npm install
2. Go to Browser http://localhost:9000
