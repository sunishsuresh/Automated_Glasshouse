import React, { Component } from 'react';

export class Loader extends React.Component {
  render() {
    return (
        <div>
          <p>Loading...</p>
        </div>
    );
  }
}

export default Loader;