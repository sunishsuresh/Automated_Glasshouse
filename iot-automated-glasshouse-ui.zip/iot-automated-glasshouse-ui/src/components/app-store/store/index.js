import configureStore from './configStore';

const store = configureStore();

export default store;