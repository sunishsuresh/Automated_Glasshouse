"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sampleRoutes = void 0;
const routes_1 = require("./routes");
Object.defineProperty(exports, "sampleRoutes", { enumerable: true, get: function () { return routes_1.sampleRoutes; } });
//# sourceMappingURL=index.js.map