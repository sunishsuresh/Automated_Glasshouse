"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.routes = void 0;
const express_1 = __importDefault(require("express"));
const formattedResponse_1 = require("../middleware/formattedResponse");
const ping_1 = require("./ping");
const device_1 = require("./device");
const sensor_1 = require("./sensor");
const sensorNow_1 = require("./sensorNow");
const date_1 = require("./date");
const glasshouse_1 = require("../middleware/glasshouse");
const dateAndTime_1 = require("../middleware/dateAndTime");
const router = express_1.default.Router({ mergeParams: true });
router.use('/ping', ping_1.pingRoutes, formattedResponse_1.formattedResponse);
router.use('/device', device_1.deviceRouter, glasshouse_1.glasshouse.uploadSensor, formattedResponse_1.formattedResponse);
router.use('/sensor', sensor_1.sensorRouter, glasshouse_1.glasshouse.getTimedSensor, formattedResponse_1.formattedResponse);
router.use('/sensorNow', sensorNow_1.sensorNowRouter, glasshouse_1.glasshouse.getLastSensor, formattedResponse_1.formattedResponse);
router.use('/date', date_1.dateRouter, dateAndTime_1.dateAndTime.getDates, formattedResponse_1.formattedResponse);
exports.routes = router;
//# sourceMappingURL=index.js.map