'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
exports.applicationConstants = void 0;
const applicationConstants = {
    CorrelationId: 'Correlation-Id',
    database: 'glasshousedb',
    collection: 'glasshouse',
    dateCollection: 'date',
    pingSuccess: 'pong'
};
exports.applicationConstants = applicationConstants;
//# sourceMappingURL=applicationConstants.js.map