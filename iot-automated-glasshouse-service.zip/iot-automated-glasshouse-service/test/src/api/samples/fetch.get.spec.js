"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const src_1 = __importDefault(require("../../../../src"));
const request = () => (0, supertest_1.default)((0, src_1.default)());
const test_helper_1 = require("../../../test-helper");
(0, test_helper_1.setUpApiTest)();
const token = (0, test_helper_1.getValidToken)();
const sample_fetch_service_1 = __importDefault(require("../../../../src/services/samples/sample-fetch.service"));
const path = '/api/samples';
const method = 'GET';
describe(`${method} ${path}/fetch`, () => {
    afterEach(() => {
        jest.clearAllMocks();
    });
    test('returns a 200', done => {
        request()
            .get('/api/samples/fetch?test=true')
            .set(test_helper_1.authHeader, token)
            .expect(200, done);
        done();
    });
    /**
     * Demonstrates using a jest mock
     */
    test('calls a service function to fetch the ping status of another application', done => {
        sample_fetch_service_1.default.prototype.pingOtherApplication = jest
            .fn()
            .mockResolvedValue({ data: 'App is up and running' });
        request()
            .get('/api/samples/fetch?test=true')
            .set(test_helper_1.authHeader, token)
            .expect(200)
            .then(response => {
            expect(response.text).toEqual('App is up and running');
            done();
        });
    });
});
//# sourceMappingURL=fetch.get.spec.js.map